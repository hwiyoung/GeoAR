package com.example.arcore.chapter7.example7_3

import java.io.File

data class ImageFile(val file: File, val width: Int, val height: Int)